@extends('layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Manage Tasks</h2>
            </div>
            <div class="pull-right">
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Status</th>
            <th>Description</th>
            <th>Project</th>
            <th width="100px">Deadline</th>
            <th width="100px">Comments</th>
            <th width="200px">Action</th>
        </tr>
        @foreach ($users as $u)
        <tr>
            <td>{{ $u['id'] }}</td>
            <td>{{ $u['title'] }}</td>
            <td>{{ $u['status'] }}</td>
            <td>{{ $u['desc'] }}</td>
            <td>{{ $u['project']->title }}</td>
            <td>{{ $u['due_date'] }}</td>
            <td>{{ $u['comments_count'] }}</td>
            <td>
				<a class="btn btn-success" href="{{ route('admins.index') }}?task_id={{ $u['id'] }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
				<a class="btn btn-danger" href="{{ route('admins.pending') }}?task_id={{ $u['id'] }}&status=Refused"><i class="fa fa-times" aria-hidden="true"></i></a>
            </td>
        </tr>
        @endforeach
    </table>
  
		<div class="d-flex justify-content-center">
			{!! $tasks->links() !!}
		</div>
      
@endsection