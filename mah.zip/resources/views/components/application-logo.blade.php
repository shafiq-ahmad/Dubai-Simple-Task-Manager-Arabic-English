<img src="{{ url('/images') }}/logo.png" alt="Logo" />
