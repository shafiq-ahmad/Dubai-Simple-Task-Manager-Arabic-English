 
<?php $__env->startSection('title', $page_title); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>

<h3 class="page-heading">Project: <?php echo e($project->title); ?></h3>
<div class="task table-responsive">
<table class="table table-bordered">
	<tr>
		<th>Task</th>
		<th>Description</th>
		<th>Deadline</th>
		<th>Status</th>
	</tr>
	
	<tr>
		<td><?php echo e($task->title); ?></td>
		<td><?php echo e($task->desc); ?></td>
		<td><?php echo e(date('d-m-Y', strtotime($task->due_date))); ?></td>
		<td><?php echo e($task->status); ?></td>
	</tr>
	
</table>
</div>
<hr/>
<h3 class="mt-4 mb-2">Comments</h3>
	<div class="row">
	<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-12">
				<div class="comment">
					<span class="info" style="color:red;"><?php echo e($c['by']); ?>: </span><span class="info">Deadline: <?php echo e($c['comment']); ?></span>
				</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php if((isset($user->role_id) && $user->role_id ==1) || (isset($user->title) && $user->id == $project->company_id)): ?>
	<div class="form">
	<form action="<?php echo e(url($url)); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="task_id" class="form-control" value="<?php echo e($task->id); ?>">
  <div class="form-group mb-3">
    <textarea class="form-control" id="comment" name="comment" rows="3" placeholder="Write your comment here..."></textarea>
  </div>
  <div class="row">
  <div class="col-6">&nbsp;</div>
  <div class="col-6">
  <button class="btn btn-primary mr-2" style="float:right;">Submit</button>
  </div>
  </div>
</form>
</div>
<?php endif; ?>
<style>
	.comment {border: 1px solid #aaa; margin-bottom:10px; padding:0 15px; line-height:40px;}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/commentView.blade.php ENDPATH**/ ?>