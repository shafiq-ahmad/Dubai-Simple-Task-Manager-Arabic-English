<img src="<?php echo e(url('/images')); ?>/logo.png" alt="Logo" />
<?php /**PATH D:\wamp\www\mah\resources\views/components/application-logo.blade.php ENDPATH**/ ?>