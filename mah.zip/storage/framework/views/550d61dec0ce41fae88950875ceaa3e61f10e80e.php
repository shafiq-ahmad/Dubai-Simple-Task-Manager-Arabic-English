
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Title:</strong>
                <input type="text" name="title" class="form-control" placeholder="Title" required value="<?php echo e($company->title ?? ''); ?>" />
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Login:</strong>
                <input type="text" name="login" class="form-control" placeholder="Login" required value="<?php echo e($company->login ?? ''); ?>" />
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            
        </div>
		<div class="col-sm-6">
			
		</div>
    </div>
<?php /**PATH D:\wamp\www\mah\resources\views/pages/companies/fields.blade.php ENDPATH**/ ?>