 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Manage Tasks</h2>
            </div>
            <div class="pull-right">
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th width="100px">Deadline</th>
            <th>Project</th>
            <th>Comments</th>
            <th width="150px">Action</th>
        </tr>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p['id']); ?></td>
            <td><?php echo e($p['title']); ?></td>
            <td><?php echo e($p['desc']); ?></td>
            <td><?php echo e($p['status']); ?></td>
            <td><?php echo e($p['due_date']); ?></td>
            <td><?php echo e($p['project']->title); ?></td>
            <td><?php echo e($p['comments_count']); ?></td>
            <td>
                <form action="<?php echo e(route('tasks.destroy',$p['id'])); ?>" method="POST">
    
                    <a class="btn btn-success" href="<?php echo e(route('tasks.index')); ?>?project_id=<?php echo e($p['id']); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                    <a class="btn btn-primary" href="<?php echo e(route('tasks.edit',$p['id'])); ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
		<div class="d-flex justify-content-center">
			<?php echo $tasks->links(); ?>

		</div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/pages/tasks/pending.blade.php ENDPATH**/ ?>