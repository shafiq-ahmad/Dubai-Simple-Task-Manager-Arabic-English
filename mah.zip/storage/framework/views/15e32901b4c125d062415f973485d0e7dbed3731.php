<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body>
	<div class="container">
			
			
<header class="row">
<div class="col-4">
    <a class="navbar-brand"
	<?php if(Auth::guard('web')->check()): ?>
        href="<?php echo e(url('/gd/companies')); ?>"
	<?php elseif(Auth::guard('company')->check()): ?>
		href="<?php echo e(url('/companies')); ?>"
	<?php endif; ?>>
      <img src="<?php echo e(url('/')); ?>/images/logo.png" alt="logo">
    </a></div>
<div class="col-8">
<nav class="navbar navbar-expand-lg navbar-light bg-light pull-right">
  <div class="container-fluid">
    <a class="navbar-brand" 
	
	<?php if(Auth::guard('web')->check()): ?>
        href="<?php echo e(url('/gd/companies')); ?>"
	<?php elseif(Auth::guard('company')->check()): ?>
		href="<?php echo e(url('/companies')); ?>"
	<?php endif; ?>
	>
	<?php if(Auth::guard('company')->user()): ?>
	<?php echo e(Auth::guard('company')->user()->title); ?>

	<?php elseif(Auth::user()): ?>
      Admin
	<?php endif; ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
	  <?php if(Auth::guard('web')->check()): ?>
        <li class="nav-item active">
          <a class="nav-link" aria-current="page" href="<?php echo e(url('/gd/projects')); ?>">Projects</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/gd/tasks')); ?>">Tasks</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/gd/archives')); ?>">Archives</a>
        </li>
        <li class="nav-item">
		  <form method="POST" action="<?php echo e(route('logout')); ?>">
			  <?php echo csrf_field(); ?>
			  <button class="btn btn-secondary">Logout</button>
           </form>
        </li>
	  <?php elseif(Auth::guard('company')->check()): ?>
        <li class="nav-item active">
		  <form method="POST" action="<?php echo e(route('logout')); ?>">
			  <?php echo csrf_field(); ?>
			  <button class="btn btn-secondary">Logout</button>
           </form>
        </li>
	  <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
</div>
		<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
        <?php $__env->startSection('sidebar'); ?>
            
        <?php echo $__env->yieldSection(); ?>
 
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    </body>
	<style>
	h2 {font-size: 24px; font-weight: bold; line-height: 40px;}
	h3 {font-size: 18px; font-weight: bold; text-align:center;}
	.box {padding: 20px 30px;background-color:#ddd;border-radius:10px;margin: 10px 0;height:150px;}
	.box span.info {font-size:70%;}
	.box i {font-size:30px; display:block; line-height: 100px; text-align:center;}
	.navbar-brand img {max-width:50px; max-height:50px;}
	.page-heading {color: #aaa; font-size:30px; font-weight: bold; line-height:90px; text-align: center;}
	</style>
</html><?php /**PATH D:\wamp\www\mah\resources\views/layouts/app.blade.php ENDPATH**/ ?>