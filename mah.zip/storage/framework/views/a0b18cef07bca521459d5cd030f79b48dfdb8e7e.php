 
<?php $__env->startSection('title', $page_title); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<h3 class="page-heading">Tasks</h3>
<h3>Project: <?php echo e($project->title); ?></h3>
	<div class="row">
	
	<?php if(Auth::guard('web')->user()): ?>
	<?php endif; ?>
		<div class="col-sm-4">
			<a href="<?php echo e(url('task/create')); ?>" >
				<div class="box">
					<i class="fa fa-plus"></i>
				</div>
			</a>
		</div>
	<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-sm-4">
			<a href="<?php echo e(url('/task') . '?task_id=' . $t['id']); ?>" >
				<div class="box">
					<?php echo e($t['title']); ?><br/>
					<span class="info">Comment Count: <?php echo e($t['comments_count']); ?></span><br/>
					<span class="info">Status: <?php echo e($t['status']); ?></span><br/>
					<span class="info">Deadline: <?php echo e(date('d-m-Y', strtotime($t['due_date']))); ?></span>
				</div>
			</a>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/taskView.blade.php ENDPATH**/ ?>