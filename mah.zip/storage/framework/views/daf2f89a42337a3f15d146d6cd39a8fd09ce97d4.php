 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2><?php echo e($page_title); ?></h2>
            </div>
            <div class="pull-right">
            </div>
        </div>
    </div>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
	<div class="responsive">
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Task</th>
            <th>Company</th>
            <th>Project</th>
            <th>Status</th>
            <th>User</th>
            <th>Description</th>
            <th>Deadline</th>
            <th>Date</th>
        </tr>
        <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
        <tr>
            <td><?php echo e($p->id); ?></td>
            <td><?php echo e($p->task); ?></td>
            <td><?php echo e($p->company); ?></td>
            <td><?php echo e($p->project); ?></td>
            <td><?php echo e($p->status); ?></td>
            <td><?php echo e($p->user); ?></td>
            <td><?php echo e($p->desc); ?></td>
            <td><?php echo e($p->deadline); ?></td>
            <td><?php echo e($p->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
		<div class="d-flex justify-content-center">
			<?php echo $archives->links(); ?>

		</div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/pages/archives/index.blade.php ENDPATH**/ ?>