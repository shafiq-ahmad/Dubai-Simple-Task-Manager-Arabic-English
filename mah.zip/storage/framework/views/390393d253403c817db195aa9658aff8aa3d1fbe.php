 
<?php $__env->startSection('title', $page_title); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
	
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<h3 class="page-heading">Company Dashboard</h3>
	<div class="row">
	<?php if(Auth::guard('web')->user()): ?>
		<div class="col-sm-4">
			<a href="<?php echo e(route('companies.create')); ?>" >
				<div class="box">
					<i class="fa fa-plus"></i>
				</div>
			</a>
		</div>
	<?php endif; ?>
	<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-sm-4">
			<a href="<?php echo e(url('/projects') . '?company_id=' . $c['id']); ?>" >
				<div class="box">
					<?php echo e($c['title']); ?> <br/>
					<span class="info">Project Count: <?php echo e($c['projects_count']); ?></span>
				</div>
			</a>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/listView.blade.php ENDPATH**/ ?>