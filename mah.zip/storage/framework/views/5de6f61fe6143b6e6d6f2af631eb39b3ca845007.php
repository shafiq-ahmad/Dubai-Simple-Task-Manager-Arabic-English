 
<?php $__env->startSection('title', $page_title); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
	
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<h3 class="page-heading">Projects</h3>
<h3>Company: <?php echo e($company->title); ?></h3>
	<div class="row">
	<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<div class="col-sm-4">
			<a href="<?php echo e(url('/tasks') . '?project_id=' . $p['id']); ?>" >
				<div class="box">
					<?php echo e($p['title']); ?><br/>
					<span class="info">Task Count: <?php echo e($p['tasks_count']); ?></span><br/>
					<span class="info">Deadline: <?php echo e(date('d-m-Y', strtotime($p['deadline']))); ?></span>
				</div>
			</a>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\mah\resources\views/projectsView.blade.php ENDPATH**/ ?>